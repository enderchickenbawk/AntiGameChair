package club.mineman.antigamingchair.commands.subcommands;

import org.bukkit.entity.*;

public interface SubCommand
{
    void execute(final Player p0, final Player p1, final String[] p2);
}

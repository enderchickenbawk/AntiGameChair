package club.mineman.antigamingchair.request.banwave;

import club.mineman.antigamingchair.request.*;

public class AGCGetBanWaveRequest extends AGCRequest
{
    public AGCGetBanWaveRequest() {
        super("get-ban-wave");
    }
}

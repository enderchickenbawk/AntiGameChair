package club.mineman.antigamingchair.util.dummy;

import net.minecraft.server.v1_8_R3.*;

public class DummyPlayerInteractManager extends PlayerInteractManager
{
    public DummyPlayerInteractManager(final World world) {
        super(world);
    }
}
